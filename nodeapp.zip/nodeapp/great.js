const indy = require('indy-sdk');

const poolName = 'indyNetwork';
const poolConfig = {
  'genesis_txn': "/home/netuser/indyNetwork/nodeapp/pool_transactions_genesis.txn"
};

const walletName = 'indy-wallet';
const walletCredentials = {
  'key': '1234'
};

function generateRandomString() {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    const charactersLength = characters.length;
    for (let i = 0; i < 32; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }

async function main() {
  try {
    const deletepool = await indy.deletePoolLedgerConfig("indyNetwork")
    await indy.createPoolLedgerConfig(poolName, poolConfig);
    // const poolHandle = await indy.openPoolLedger(poolName, poolConfig);
    
    const walletHandle = await indy.openWallet({ id: walletName }, walletCredentials);
    const [did, verkey] = await indy.createAndStoreMyDid(walletHandle, { seed: '00000000000000000000000000000My1' });
    const didRequest = await indy.buildNymRequest(null, did, verkey, null, 'TRUST_ANCHOR');
    const signedRequest = await indy.signRequest(walletHandle, did, didRequest);
    const result = await indy.submitRequest(poolHandle, signedRequest);
    
    console.log(result);
    await indy.closeWallet(walletHandle);
    await indy.closePoolLedger(poolHandle);
    await indy.deletePoolLedgerConfig(poolName);
  } catch (err) {
    console.error(err);
  }
}

main();