const indy = require('indy-sdk');
//example register from seed
regseed = {role: "ENDORSER", alias: null, did: null, seed: "12345678123456781234567812345678"}
//example register using indy
const regdid = {"role":"ENDORSER","alias":null,"did":"9dzr2rhmDGHskohRgEv8uZ","verkey":"5i4Wn3oba1GfmzyMKvYm9K4oWiTDAnExD19uq18qmix7"}
// Set up the Indy pool configuration
const poolName = 'indyNetwork';
const poolConfig = {
  'genesis_txn': "/home/netuser/indyNetwork/nodeapp/pool_transactions_genesis.txn"
};

// Set up the Indy wallet configuration
const walletName = 'indy-wallet';
const walletConfig = {
  'id': walletName
};
const walletCredentials = {
  'key': '1234'
};
async function createRequest(req) {
    const deletepool = await indy.deletePoolLedgerConfig("indyNetwork")
    const pool = await indy.createPoolLedgerConfig("indyNetwork",poolConfig)
    const poolHandle = await indy.openPoolLedger(poolName, poolConfig);
    const walletHandle = await indy.openWallet(walletConfig, walletCredentials);
        // const [did, verkey] = await indy.createAndStoreMyDid(walletHandle, {seed:req.seed});
        // const didRequest = await indy.buildNymRequest("V4SGRU86Z58d6TV7PBUe6f", did, verkey, "user", "TRUST_ANCHOR");
        // console.log(didRequest)
        // const dataa = await indy.listMyDidsWithMeta(walletHandle)
        // console.log("data  ===="+JSON.stringify(dataa))
        // const regdid =await indy.signRequest(walletHandle, "V4SGRU86Z58d6TV7PBUe6f", didRequest);
        // // indy.signWithAddress
        // indy.cry
        // const result = await indy.submitRequest(poolHandle, regdid)
        // console.log("result ==="+JSON.stringify(result))
        // const data = {
        //     "did":req.did,
        //     "seed":null,
        //     "verkey":req.verkey
        // }
        // return data
    // }
    // else if(req.type == "DID") {
        const didRequest = await indy.buildNymRequest("V4SGRU86Z58d6TV7PBUe6f", req.did, req.verkey, "User", 'TRUST_ANCHOR');
        const regdid =await indy.signRequest(walletHandle, "V4SGRU86Z58d6TV7PBUe6f", didRequest);
        const result = await indy.submitRequest(poolHandle, regdid)
        console.log(result)
        const data = {
            "did":req.did,
            "seed":null,
            "verkey":req.verkey
        }
        return data
    // }

}

module.exports.createRequest = createRequest;