const indy = require('indy-sdk');

const poolName = 'indyNetwork';
const poolConfig = {
  "genesis_txn": "/home/netuser/indyNetwork/nodeapp/services/pool_transactions_genesis.txn"
};

const walletName = 'indy-wallet';
const walletConfig = {
  'id': walletName
};
const walletCredentials = {
  'key': '1234'
};

async function main() {
  try {
    await indy.deletePoolLedgerConfig("indyNetwork")
    await indy.createPoolLedgerConfig(poolName, poolConfig);
    const poolHandle = await indy.openPoolLedger(poolName, poolConfig);
    // await indy.deleteWallet(walletConfig, walletCredentials)
    await indy.createWallet(walletConfig, walletCredentials);
    const walletHandle = await indy.openWallet({ id: walletName }, walletCredentials);
    
    // Create steward DID and verkey
    const [stewardDid, stewardKey] = await indy.createAndStoreMyDid(walletHandle, { seed: '000000000000000000000000Trustee1' });
    
    // Create a new DID and verkey to be added to the ledger
    const [did, verkey] = await indy.createAndStoreMyDid(walletHandle, {});
    
    // Build the NYM request to add the new DID and verkey to the ledger
    const nymRequest = await indy.buildNymRequest(stewardDid, did, verkey, null, 'TRUST_ANCHOR');
    let list = await indy.listMyDidsWithMeta(walletHandle)
    console.log(list)
    // Sign the NYM request with the steward's DID and verkey
    console.log("steward did = "+stewardDid)
    const signedRequest = await indy.signRequest(walletHandle, stewardDid, nymRequest);
    // await indy.multiSignRequest
    // Submit the signed NYM request to the ledger
    const result = await indy.submitRequest(poolHandle, signedRequest);
    
    console.log(result);
    
    await indy.closeWallet(walletHandle);
    await indy.closePoolLedger(poolHandle);
    // await indy.deletePoolLedgerConfig(poolName);
  } catch (err) {
    console.error(err);
  }
}

main();
