

const indy = require('indy-sdk')


// function console.console.log() {
//     console.log(colors.CYAN, ...arguments, colors.NONE)
// }
const poolName = 'indyNetwork'
const genesisFilePath = "/home/netuser/indyNetwork/nodeapp/services/pool_transactions_genesis.txn"
const poolConfig = {'genesis_txn': genesisFilePath}
const walletName = {"id": "wall3"}
const walletCredentials = {"key": "wallet_key"}
let poolHandle;
let walletHandle;
let trustAnchorDid
let trustAnchorVerkey
async function run() {
    await indy.createPoolLedgerConfig(poolName, poolConfig)
    poolHandle = await indy.openPoolLedger(poolName, undefined)
    await indy.createWallet(walletName, walletCredentials)
    walletHandle = await indy.openWallet(walletName, walletCredentials)
    const TrusteeSeed = '000000000000000000000000Trustee2'
    const did = {'seed': TrusteeSeed}
    const [TrusteeDid, TrusteeVerkey] = await indy.createAndStoreMyDid(walletHandle, did)
    // const [trustAnchorDid, trustAnchorVerkey] = await indy.createAndStoreMyDid(walletHandle, "{}")
// console.log(trustAnchorDid+" === "+trustAnchorVerkey)
    const nymRequest = await indy.buildNymRequest( TrusteeDid, "M5EUy44eVhjrpTgKkYgoY6", "BwYgcQqGSHSKRhshmu7dZuifjqJJLi8io7tCtLGjSwyT", "chirag",'TRUST_ANCHOR')
        // await indy.signRequest();
    const res=await indy.signAndSubmitRequest(poolHandle,walletHandle,
                                   TrusteeDid,
                                    nymRequest)
    console.log("res"+JSON.stringify(res))
    // const [clientDid, clientVerkey] = await indy.createAndStoreMyDid(walletHandle, "{}")
    // const getNymRequest = await indy.buildGetNymRequest(clientDid,)
    // const getNymResponse = await indy.submitRequest(poolHandle,getNymRequest)
    await indy.closeWallet(walletHandle)
    await indy.closePoolLedger(poolHandle)
    await indy.deleteWallet(walletName, walletCredentials)
    await indy.deletePoolLedgerConfig(poolName)
  
}
try {
    run()
} catch (e) {
    console.log("ERROR occured : e")
    const p1 = new Promise(async (resolve) => {
        await indy.closeWallet(walletHandle)
        await indy.closePoolLedger(poolHandle)
        await indy.deleteWallet(walletName, walletCredentials)
        await indy.deletePoolLedgerConfig(poolName)
    resolve(1);
    }
    ); 
    
    
}