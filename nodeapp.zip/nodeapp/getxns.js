const indy = require('indy-sdk');

async function listTransactions() {
  // Connect to the Indy network
  const poolName = 'indyNetwork';
  const poolConfig = '{"genesis_txn": "/home/netuser/indyNetwork/nodeapp/services/pool_transactions_genesis.txn"}';
  // await indy.deletePoolLedgerConfig("indyNetwork")
    // await indy.createPoolLedgerConfig(poolName, poolConfig);
    const poolHandle = await indy.openPoolLedger(poolName, poolConfig);

  // Create a new wallet
//   const walletName = 'txn-wallet';
//   const walletConfig = {
//     'id': walletName
//   };
//   const walletCredentials = {
//     'key': '1234'
//   };
//   await indy.createWallet(walletConfig, walletCredentials);

  // Open the wallet
//   const walletHandle = await indy.openWallet(walletConfig, walletCredentials);

  // Get the last transaction on the ledger
  await indy.setProtocolVersion(2)
  const getTxnResponse = await indy.submitRequest(poolHandle, JSON.stringify({
    reqId: 15,
    identifier: 'F7ehzpnqwd3VHKMhdSJQeC',
    operation: {
      type: '3',
      data : 15
    },
    'protocolVersion': 2
  }));
  console.log(JSON.stringify(getTxnResponse))
  let p = []
  // const lastTxnSeqNo = JSON.parse(getTxnResponse).result.data.ledgerSize;

  // List all transactions on the ledger
  // for (let seqNo = 1; seqNo <= 15; seqNo++) {
  //   const getTxnResponse = await indy.submitRequest(poolHandle, JSON.stringify({
  //     reqId: 1,
  //     identifier: "F7ehzpnqwd3VHKMhdSJQeC",
  //     operation: {
  //       type: '3',
  //       data: seqNo
  //     },
  //     'protocolVersion': 2
  //   }));
  //   p.
  // }

  // Close the wallet and pool connections
//   await indy.closeWallet(walletHandle);
  await indy.closePoolLedger(poolHandle);
}

listTransactions();