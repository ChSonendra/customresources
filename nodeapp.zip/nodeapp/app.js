// const { createPoolLedgerConfig, deletePoolLedgerConfig } = require('indy-sdk');
const indy = require('indy-sdk');
// const express = require('express')
// bodyParser = require('body-parser').json();
// const app = express()
const createRequest = require('./services/createRequestService')
// Set up the Indy pool configuration
const poolName = 'indyNetwork';
const poolConfig = {
  'genesis_txn': "/home/netuser/indyNetwork/nodeapp/pool_transactions_genesis.txn"
};
// const port = 3000
// Set up the Indy wallet configuration
const walletName = 'indy-wallet';
const walletConfig = {
  'id': walletName
};
const walletCredentials = {
  'key': '1234'
};
// app.get('/genesis', (req, res) => {
//   console.log("Cdsvdsf")
// res.send(`{"reqSignature":{},"txn":{"data":{"data":{"alias":"node1","blskey":"3AedMDCP4hGqdHNs3nL3Q4KvTgzgphduWL5TPhBz3ixuF9EAFbQkC4PAf6KLHK2kFMFmFgKMd2PdbLkHi87cun2ESr85525Vrpth1GGayzLRj7P3dwvPebPWsmXTd113EkitRgu6417DiZRFbUEtCV5uoCcoLgiGNaPymNDf9JTgxz2","blskey_pop":"RBoc6U6niKZZgt8gcr1v4hy54ZtWJ9LLwhbbvSsa71NEHAV6hTLZ8tcVJ4wKGnAHBiznUPvoFzciGSBykTfgafpGGqre4Dnu6NxBa1hKSasUNtGP5dbbi9Pg89feyoZGnwBEr5qZqvgcwtuGGeCVqepEVGbeZTrpku3eSAaeKLANo9","client_ip":"34.174.245.253","client_port":"9702","node_ip":"34.174.245.253","node_port":"9701","services":["VALIDATOR"]},"dest":"8985dZ1hpANvemGy2Fs4PfyMvXdipN9zz3bqX19ybGWr"},"metadata":{"from":"E6oxYjxwKCiF7jbfzxomCz"},"type":"0"},"txnMetadata":{"seqNo":1,"txnId":"ca12f31b8cbf5f29e268ea64c20a37f3d50b539d891db0c3ebc7c0f66b1fb98a"},"ver":"1"}
// {"reqSignature":{},"txn":{"data":{"data":{"alias":"node2","blskey":"45Toz8e2vSMf8PXwQDN2oFLEM15t2gGTFD4bGsTicxD4Sj6KzyVzruZLCFA9rSgm88hCux1Rjdt13xdA4BT8r1rGtJKFH5nh9a24chdNLovWLfgQYhaUVYpTn1TvUhq9qassuZiDS6TTqQqorYxfnXmFnxnfB7Ur3zBM6JhnJPYCRwi","blskey_pop":"RP1CQqQ3vvbKFA5drLeihq8MuhkxvJzWt1gejTc4ie2s74jdh54DgzVRitpgRHfUhMYJWa69hi6xHgZmPNHfS5YzyxjBCZHr6dYQaHK6KFFonnikmaP63UYzunQYqexcV9xPRDJc5yXg5AWRZeUhsV5VXJW8BQLQf9DBJvC7wGbJGw","client_ip":"34.174.245.253","client_port":"9704","node_ip":"34.174.245.253","node_port":"9703","services":["VALIDATOR"]},"dest":"2Q9y3Jukh7CX1R31sggLRHAUbpMQodA9k21BftWNVS6D"},"metadata":{"from":"3Zu6c6CYK1dqQARqcSaRFV"},"type":"0"},"txnMetadata":{"seqNo":2,"txnId":"15b18a7243257695704f66a3b1ddc9311194fc7d2e1896f440cc517c777ab7ec"},"ver":"1"}
// {"reqSignature":{},"txn":{"data":{"data":{"alias":"node3","blskey":"2RKkg8WkNBeaWRbfo2WvgZMtpJuxg2f5yBn2Gg6yw87jyxqWFpshYXHusnc1JDQoLF3cinEh9nY8vE6vDJFcysioqtcRfziiohLFd6jU733e11Mzsu9KTupcsNScjx1FxuNFSCXcaPWZkaGMMb1Ws37m3dnyKFqzAHRWfdx7HGuc3bk","blskey_pop":"RPAj6bWGNqNyHTyBEpiJsaUpL7XcHGgTmFoBWZVUcc2JemjRsPF9sM44UzaJm4XWXHNu9vDnENEEeH3Hx8rjnMzsFGgi42GkcB44vkmMDZNTCCGnE7SCreSNWKzBvnt9QmFwAuGq6jcsvxGzJCF8LPkxTUYuwttnMpnff5ZCLcVd8j","client_ip":"34.174.245.253","client_port":"9706","node_ip":"34.174.245.253","node_port":"9705","services":["VALIDATOR"]},"dest":"JA3LLAfCCWJ2AqGjQ5RWRWBC2rVLAWVysCZoocRzLeVN"},"metadata":{"from":"YUeayQyg8mJBwH7qdzLdr1"},"type":"0"},"txnMetadata":{"seqNo":3,"txnId":"3b5bb1c6e7b76daba8afd89516e24140a67fc6be2ba071cc3b97d1b2e08c238d"},"ver":"1"}
// {"reqSignature":{},"txn":{"data":{"data":{"alias":"node4","blskey":"1cAnpprugGFyr9i5zf76Uufsrc5qZrmumYyAi94iasXt8LmVbtZpob2EN6PAmHhkKSmBaRAHZJPnYgnweaLKdWKjRG4YQNQFiEafmA2Pybu8NcCNgXLjxoCD3CooNTjk44xVA4mPhAyw96MuiPbY5yxqRuQkUKw4LWgeFX3WoSa6Ly","blskey_pop":"QsVkmEyfPdJDGHis47ZFSBwdqQVgZL46soTC61VQNCwEBPo7DGM4rtgYfAJp8N32nitLdFckiCYazC9wnazwXzE6MddCHv3dq6CYottDWDpLiWrTBKjZ63TqxZjHEQyYWrKrRKkmGh43xQPBhnKpnitKNa7GwDywobiAkkTAbqGM2X","client_ip":"34.174.245.253","client_port":"9708","node_ip":"34.174.245.253","node_port":"9707","services":["VALIDATOR"]},"dest":"E6TL4aqKRj7U2aKEh3NgtxQAZQigR7LpPSQqiza7XZ26"},"metadata":{"from":"R2QahsmLCtj5Pi6pY8KPF2"},"type":"0"},"txnMetadata":{"seqNo":4,"txnId":"d2b8f62a7e335bbd5576c8422844760f22ec378009eeea790c41e4dc45f23c33"},"ver":"1"}
// `)
// })
// app.post('/register',bodyParser, (req, res) => {
//   console.log("request === "+JSON.stringify(req.body))
//   const responsedata = createRequest.createRequest(req.body)
//   res.send(responsedata)
// })
// app.listen(port, () => {
//   console.log(`Example app listening on port ${port}`)
// })
function generateRandomString() {
  let result = '';
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  const charactersLength = characters.length;
  for (let i = 0; i < 32; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}
async function main() {
  console.log(poolName, poolConfig)
  const deletepool = await indy.deletePoolLedgerConfig("indyNetwork")
  console.log(deletepool)
  const pool = await indy.createPoolLedgerConfig("indyNetwork",poolConfig)
  console.log()
  const poolHandle = await indy.openPoolLedger(poolName, poolConfig);
  console.log("vfdvdf"+JSON.stringify(poolHandle))
  console.log("vfv 28")
  // await indy.deleteWallet(walletConfig, walletCredentials)
  const seed = generateRandomString()
console.log("seed == "+seed)
// console.log(result);
// await indy.deleteWallet(walletConfig, walletCredentials)
//   await indy.createWallet(walletConfig, walletCredentials);
  const walletHandle = await indy.openWallet(walletConfig, walletCredentials);
  console.log("vfdvdf1"+ walletHandle)
  // await indy.createAndStoreMyDid(walletHandle, {seed:"000000000000000000000000Trustee1"});
  const [did, verkey] = await indy.createAndStoreMyDid(walletHandle, {seed:seed});
  console.log("vfdvdf1 ======== "+did)
  const dataa = await indy.listMyDidsWithMeta(walletHandle)
  console.log("cdcvfvfgrv"+JSON.stringify(dataa))
  const didRequest = await indy.buildNymRequest("V4SGRU86Z58d6TV7PBUe6f", did, verkey, "user0001", 'TRUST_ANCHOR');
  console.log("did req ====================="+JSON.stringify(didRequest))
  console.log("Wallet handle === "+ walletHandle)
  // const ddd = await indy.wallet(walletHandle)
  // console.log("wallet record ======= "+ddd)
  // const data = await indy.storeTheirDid(walletHandle,{did:"V4SGRU86Z58d6TV7PBUe6f",verkey:"~CoRER63DVYnWZtK8uAzNbx"})
  // console.log(data)
  const listofdids = await indy.listMyDidsWithMeta(walletHandle)
  console.log(listofdids)
  const regdid =await indy.signRequest(walletHandle, "V4SGRU86Z58d6TV7PBUe6f", didRequest);
  // console.log("done === "+regdid)
  const result = await indy.submitRequest(poolHandle, regdid)
  // Close the wallet and pool
  console.log(JSON.stringify(result))
  await indy.closeWallet(walletHandle);
  console.log("done === closin")
  await indy.closePoolLedger(poolHandle);
}

main().catch(err => {
    console.log(err)
});
